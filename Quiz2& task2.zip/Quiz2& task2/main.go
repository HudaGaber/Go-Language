package main

import "fmt"

func double(arr [3]int) {
	for i := range arr {
		arr[i] *= 2
	}
}

func counter(n int) {
	if n == 0 {
		return
	}
	fmt.Println(n)
	counter(n - 1)
}

func fibonacci(n int) int {
	if n < 0 {
		return -1

	}
	if n == 0 {
		return 0
	}
	if n == 1 {
		return 1

	}
	return fibonacci(n-1) + fibonacci(n-2)
}
func reverse(s string) string {
	runes := []rune(s)

	if len(runes) <= 1 {
		return s
	}

	return string(runes[len(runes)-1]) + reverse(string(runes[:len(runes)-1]))
}
func main() {
	// // task1

	// x := 10
	// defer fmt.Println("First:", x)

	// x = 20
	// defer func() {
	// 	fmt.Println("Second:", x)
	// }()

	// x = 30
	// defer fmt.Println("Task 1:")
	// fmt.Println("Task 2:")
	// counter(10)
	// fmt.Println("Task 3:")
	// nums := [3]int{1, 2, 3}
	// double(nums)
	// fmt.Println(nums) // Output ??

	x := []int{1, 2, 3}
	y := &x
	x[0] = 100
	fmt.Println(x)
	fmt.Println(*y)

	for i := 0; i < 8; i++ {
		fmt.Printf("%d ", fibonacci(i))
	}
	word := reverse("Hello")
	fmt.Println(word)

}
