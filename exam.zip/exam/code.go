package main
import (
	"context"
)
// import ("fmt";  
// "sort" ;"time"
// "sync")
//--------------------task1--------------------------------------
// func maxSlidingWindow(nums []int, k int) []int {
// 	var result []int
// 	var deque []int
// 	for i := 0; i < len(nums); i++ {
// 		if len(deque) > 0 && deque[0] <= i-k {
// 			deque = deque[1:]}
// 		for len(deque) > 0 && nums[deque[len(deque)-1]] <= nums[i] {
// 			deque = deque[:len(deque)-1]}
// 		deque = append(deque, i)
// 		if i >= k-1 {
// 			result = append(result, nums[deque[0]])}
// 	}
// 	return result
// }
//--------------------task2--------------------------------------
// func groupAnagrams(words []string) [][]string {
// 	groups := make(map[[26]int][]string)
// 	var order [][26]int
// 	for _, word := range words {
// 		var key [26]int
// 		for _, ch := range word {
// 			key[ch-'a']++
// 		}
// 		if _, exists := groups[key]; !exists {
// 			order = append(order, key)
// 		}
// 		groups[key] = append(groups[key], word)
// 	}
// 	var result [][]string
// 	for _, key := range order {
// 		result = append(result, groups[key])
// 	}
// 	return result
// }
//--------------------task3--------------------------------------

// type Student struct {
// 	name   string
// 	id     int
// 	grades map[string]float64
// }

// func (s Student) Average() float64 {
// 	if len(s.grades) == 0 {
// 		return 0}
// 	var sum float64
// 	for _, grade := range s.grades {
// 		sum += grade
// 	}
// 	return sum / float64(len(s.grades))
// }
// func TopStudent(students []Student) *Student {
// 	if len(students) == 0 {
// 		return nil
// 	}
// 	top := 0
// 	for i := 1; i < len(students); i++ {
// 		if students[i].Average() > students[top].Average() {
// 			top = i
// 		}
// 	}
// 	return &students[top]}

//--------------------task4--------------------------------------
// type Person struct {
// 	Name string
// 	Age  int
// }
// type ByAge []Person
// func (p ByAge) Len() int {
// 	return len(p)}
// func (p ByAge) Less(i, j int) bool {
// 	return p[i].Age < p[j].Age}
// func (p ByAge) Swap(i, j int) {
// 	p[i], p[j] = p[j], p[i]
// }
// type Ranker interface {
// 	Len() int
// 	Less(i, j int) bool
// 	Swap(i, j int)
// }

// func SortRanker(r Ranker) {
// 	sort.Sort(r)
// }
//--------------------task5--------------------------------------
// func Retry(times int, fn func() error) error {
// 	var err error
// 	delay := time.Second
// 	for i := 1; i <= times; i++ {
// 		err = fn()
// 		if err == nil {
// 			return nil
// 		}
// 		if i < times {
// 			time.Sleep(delay)
// 			delay *= 2}}
// 	return fmt.Errorf("after %d attempts: %w", times, err)
// }
//--------------------task8--------------------------------------
// func ParallelSum(nums []int, workers int) int {
// 	var wg sync.WaitGroup
// 	results := make(chan int, workers)
// 	chunkSize := (len(nums) + workers - 1) / workers
// 	for i := 0; i < workers; i++ {
// 		start := i * chunkSize
// 		end := start + chunkSize
// 		if start >= len(nums) {
// 			break}
// 		if end > len(nums) {
// 			end = len(nums)
// 		}
// 		wg.Add(1)
// 		go func(part []int) {
// 			defer wg.Done()
// 			sum := 0
// 			for _, n := range part {
// 				sum += n
// 			}
// 			results <- sum
// 		}(nums[start:end])
// 	}
// 	wg.Wait()
// 	close(results)
// 	total := 0
// 	for r := range results {
// 		total += r
// 	}
// 	return total
// }

func main (){
	// nums := []int{1, 3, -1, -3, 5, 3, 6, 7}
	// k := 3
	// fmt.Println(maxSlidingWindow(nums, k))
	// words := []string{"eat", "tea", "tan", "ate", "nat", "bat"}
	// fmt.Println(groupAnagrams(words))
	// students := []Student{
	// 	{"Ahmed", 1, map[string]float64{"Math": 90, "English": 80}},
	// 	{"Ali", 2, map[string]float64{"Math": 95, "English": 92}},
	// 	{"Sara", 3, map[string]float64{"Math": 85, "English": 88}},
	// }
	// top := TopStudent(students)
	// fmt.Println("Top Student:", top.name)
	// fmt.Println("Average:", top.Average())
//     people := ByAge{
// 		{"Ahmed", 25},
// 		{"Sara", 20},
// 		{"Ali", 30},}
// 	SortRanker(people)
// 	fmt.Println(people)
// count := 0
// err := Retry(3, func() error {
// 		count++
// if count < 3 {
// 			return fmt.Errorf("failed")
// 		}
// 		return nil
// 	})
// 	fmt.Println(err)

//--------------------task7--------------------------------------
	// rate := 5
	// ticker := time.NewTicker(time.Second / time.Duration(rate))
	// defer ticker.Stop()
	// for i := 1; i <= 20; i++ {
	// 	<-ticker.C
	// 	fmt.Println("Processing task", i)
	// }

	// nums := []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
	// fmt.Println(ParallelSum(nums, 3))
ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	handlers := map[string]Handler{
		"email":  EmailHandler{},
		"resize": ResizeImageHandler{},
		"report": ReportHandler{},
	}
	tasks := make(chan Task)
	go func() {
		defer close(tasks)
		tasks <- Task{
			ID:      1,
			Name:    "email",
			Payload: map[string]any{},
		}
		tasks <- Task{
			ID:      2,
			Name:    "resize",
			Payload: map[string]any{},
		}
		tasks <- Task{
			ID:      3,
			Name:    "report",
			Payload: map[string]any{},
		}
	}()
	results := workerPool(ctx, 3, tasks, handlers)
	printSummary(results)
}

