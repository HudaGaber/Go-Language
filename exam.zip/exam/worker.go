package main

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"time"
)
type Task struct {
	ID       int
	Name     string
	Payload  map[string]any
	Priority int
}
type Handler interface {
	Handle(ctx context.Context, t Task) error
}
type RetryableError struct {
	Msg string
}
func (e *RetryableError) Error() string {
	return e.Msg
}
type PanicError struct {
	Value any
}
func (e *PanicError) Error() string {
	return fmt.Sprintf("panic: %v", e.Value)
}
type EmailHandler struct{}
func (EmailHandler) Handle(ctx context.Context, t Task) error {
	if t.Payload["retry"] == true {
		return &RetryableError{Msg: "email temporary failure"}
	}
	fmt.Println("Email task:", t.ID)
	return nil
}
type ResizeImageHandler struct{}
func (ResizeImageHandler) Handle(ctx context.Context, t Task) error {
	if t.Payload["panic"] == true {
		panic("image resize panic")
	}
	fmt.Println("Resize task:", t.ID)
	return nil
}
type ReportHandler struct{}
func (ReportHandler) Handle(ctx context.Context, t Task) error {
	fmt.Println("Report task:", t.ID)
	return nil
}
type Result struct {
	TaskID   int
	Success  bool
	Retried  bool
	Panicked bool
	Err      error
	Duration time.Duration
}
func safeHandle(ctx context.Context, h Handler, t Task) (err error) {
	defer func() {
		if r := recover(); r != nil {
			err = &PanicError{Value: r}
		}
	}()

	return h.Handle(ctx, t)
}
func processTask(ctx context.Context, t Task, h Handler) Result {
	start := time.Now()
	result := Result{
		TaskID: t.ID,
	}
	const maxRetries = 3
	for attempt := 0; attempt <= maxRetries; attempt++ {
		err := safeHandle(ctx, h, t)
		if err == nil {
			result.Success = true
			result.Duration = time.Since(start)
			return result
		}
		var panicErr *PanicError
		if errors.As(err, &panicErr) {
			result.Panicked = true
			result.Err = err
			result.Duration = time.Since(start)
			return result
		}
		var retryErr *RetryableError
		if errors.As(err, &retryErr) && attempt < maxRetries {
			result.Retried = true
			continue
		}
		result.Err = fmt.Errorf("task %d failed: %w", t.ID, err)
		result.Duration = time.Since(start)
		return result
	}
	return result
}
func workerPool(
	ctx context.Context,
	workers int,
	tasks <-chan Task,
	handlers map[string]Handler,
) []Result {
	var wg sync.WaitGroup
	var mu sync.Mutex
	results := []Result{}
	worker := func() {
		defer wg.Done()
		for {
			select {
			case <-ctx.Done():
				return
			case task, ok := <-tasks:
				if !ok {
					return
				}
				handler, exists := handlers[task.Name]
				if !exists {
					r := Result{
						TaskID: task.ID,
						Err:    fmt.Errorf("no handler for %s", task.Name),
					}
					mu.Lock()
					results = append(results, r)
					mu.Unlock()
					continue
				}
				r := processTask(ctx, task, handler)

				mu.Lock()
				results = append(results, r)
				mu.Unlock()
			}
		}
	}

	for i := 0; i < workers; i++ {
		wg.Add(1)
		go worker()
	}

	wg.Wait()

	return results
}
func printSummary(results []Result) {

	succeeded := 0
	failed := 0
	retried := 0
	panicked := 0
	var totalDuration time.Duration
	for _, r := range results {
		if r.Success {
			succeeded++
		} else {
			failed++}
		if r.Retried {
			retried++}
		if r.Panicked {
			panicked++}
		totalDuration += r.Duration}
	var average time.Duration
	if len(results) > 0 {
		average = totalDuration / time.Duration(len(results))
	}
	fmt.Println("\n----- Summary -----")
	fmt.Println("Succeeded:", succeeded)
	fmt.Println("Failed:", failed)
	fmt.Println("Retried:", retried)
	fmt.Println("Panicked:", panicked)
	fmt.Println("Average Duration:", average)
}